-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- 主机: localhost:3306
-- 生成日期: 2019 年 11 月 04 日 21:57
-- 服务器版本: 5.6.46-log
-- PHP 版本: 5.6.40

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `s2498084`
--

-- --------------------------------------------------------

--
-- 表的结构 `msg_api`
--

CREATE TABLE IF NOT EXISTS `msg_api` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `url` text,
  `post` text,
  `status` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `msg_config`
--

CREATE TABLE IF NOT EXISTS `msg_config` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `switch` int(1) NOT NULL DEFAULT '1',
  `user` varchar(250) NOT NULL,
  `pwd` varchar(250) NOT NULL,
  `login` text,
  `title` text,
  `qq` text,
  `face_image` text,
  `phone` text,
  `syskey` text,
  `jiage` text,
  `zsye` text,
  `kmtips` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `msg_config`
--

INSERT INTO `msg_config` (`id`, `switch`, `user`, `pwd`, `login`, `title`, `qq`, `face_image`, `phone`, `syskey`, `jiage`, `zsye`, `kmtips`) VALUES
(1, 1, 'admin', '123456', 'password', '短信轰炸系统', '1922268970', '', '13888888888', '121', '1', '10', '购买卡密可联系客服：1922268970进行购买！');

-- --------------------------------------------------------

--
-- 表的结构 `msg_km`
--

CREATE TABLE IF NOT EXISTS `msg_km` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `km` text,
  `money` varchar(30) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `msg_log`
--

CREATE TABLE IF NOT EXISTS `msg_log` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `user` text,
  `phone` text,
  `money` text,
  `date` text,
  `ip` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `msg_notice`
--

CREATE TABLE IF NOT EXISTS `msg_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `center` text,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `msg_phone`
--

CREATE TABLE IF NOT EXISTS `msg_phone` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `phone` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `user_list`
--

CREATE TABLE IF NOT EXISTS `user_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` text,
  `pass` varchar(30) DEFAULT NULL,
  `qq` varchar(30) DEFAULT NULL,
  `key` varchar(30) DEFAULT NULL,
  `status` text,
  `money` float DEFAULT NULL,
  `dta` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
